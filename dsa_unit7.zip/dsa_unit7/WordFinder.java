package dsa_unit7;
import java.io.*;
import java.util.*;
import java.util.Scanner;
import java.io.FileNotFoundException;
public class WordFinder {

	public static void main(String[] args) {
		// file reading implementation
		System.out.println("The Great Book of Bridges");
		String fileName = "dsa_unit7/BookofBridges.txt"; // txt file  location
		File file = new File(fileName);
		List<String> words = new ArrayList<>();

		try {
			// Scans the file
			Scanner scanner = new Scanner(file);
			while (scanner.hasNext()) {
				String word = scanner.next().toLowerCase().replaceAll("[,? .!]", " "); // loop to go take out all the grammar marks
				words.add(word);
			}
			scanner.close();

			// runs timer on for TreeMap
			long startTime = System.nanoTime();
			// Priority Queue Method where it does the word finding , how many times it appears
			Map<String, Integer> wordCount = new TreeMap<>();

			for (String word : words) {
				wordCount.put(word, wordCount.getOrDefault(word, 0) + 1);
			}
			//Top 5 most frequent word search
			PriorityQueue<Map.Entry<String, Integer>> heap = new PriorityQueue<>(Comparator.comparing(Map.Entry::getValue));
			for (Map.Entry<String, Integer> entry : wordCount.entrySet()) {
				heap.add(entry);
				if (heap.size() > 5) {
					heap.poll();
				}
			}
			while (!heap.isEmpty()) {
				Map.Entry<String, Integer> entry = heap.poll();
				System.out.println(entry.getKey() + " " + entry.getValue());
			}

			long endTime = System.nanoTime();
			long totalTime = endTime - startTime;
			System.out.println("Total time for the TreeMap : " + totalTime + " ns");
			// run timer & Priority Queue Mehtod for HashMap
			startTime = System.nanoTime();
			wordCount = new HashMap<>();
			for (String word : words) {
				wordCount.put(word, wordCount.getOrDefault(word, 0) + 1);
			}
			heap = new PriorityQueue<>(Comparator.comparing(Map.Entry::getValue));
			for (Map.Entry<String, Integer> entry : wordCount.entrySet()) {
				heap.add(entry);

				if (heap.size() > 5) {
					heap.poll();
				}
			}
			while (!heap.isEmpty()) {
				Map.Entry<String, Integer> entry = heap.poll();
				System.out.println(entry.getKey() + " " + entry.getValue());
			}
			endTime = System.nanoTime();
			totalTime = endTime - startTime;
			System.out.println("Total time for the HashMap : " + totalTime + " ns");
		} catch (FileNotFoundException e) {
			System.out.println("Can't find file " + fileName);
		} catch (Exception e) {
			System.out.println("Other error: " + e.getMessage());
			//e.printStackTrace();
		}
	}

}